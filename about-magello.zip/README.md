![Magello Group Logotype](/logotype/PNG_RGB/Magello_Magenta_RGB.png)

# 🚀 Nya möjligheter på Magello Group!

Magello är det inkluderande konsultbolaget. Vi är öppna, trygga och såklart väldigt duktiga på det vi gör. Om du är en person som tycker att gemenskap, teamkraft och att skratta är det viktigaste för att du ska kunna gör det bästa jobbet så är vi företaget för dig.

## Vi söker alltid efter 

Vi är produkt och teknikoberoende. Vi utvecklar i allt från Kotlin, Python & till Go men huvudsakligen inom Java och .Net ekosystemen, och vi gillar open source.

* Fullstack
* Backend
* Frontend
* DevOps
* ... och andra intressanta personer!

[Läs mer på jobb.magello.se](https://jobb.magello.se/jobs)

Vi finns i Stockholm och Linköping och hjälper några av Sveriges mäst kända varumärken med **integrationer**, **cloud** och **digitala tjänster**. 

Har du ett projekt eller repo du är stolt över, plinga mig 😃 så kanske vi kan bli kollegor!

Puss & kram

_Patric_

___

E-post: [patric.jansson@magello.se](mailto:patric.jansson@magello.se)

Linkedin: [patricjansson](http://linkedin.com/in/patricjansson/)

Twitter: [patricjansson](https://twitter.com/patricjansson)

Instagram: [magello_patric](http://instagram.com/magello_patric/)
