
## ![#009EE3](https://placehold.co/15x15/009EE3/009EE3.png) Blå
**CMYK**: 100, 30, 0, 11

**RGB**: 0, 158, 277, 89 

**HEX**: #009EE3

**PMS**: 2925C 
 
## ![#00A65D](https://placehold.co/15x15/00A65D/00A65D.png) Grön

**CMYK**: 100, 0, 44, 35 

**RGB**: 0, 166, 93, 65

**HEX**: #00A65D 

**PMS**: 7739C 

## ![#ffdd00](https://placehold.co/15x15/ffdd00/ffdd00.png) Gul
**CMYK**: 0, 13, 100, 0

**RGB**: 255, 221, 0, 100

**HEX**: #ffdd00

**PMS**: 107C

## ![#FDB913](https://placehold.co/15x15/009EE3/FDB913.png) Senapsgul
**CMYK**: 0, 27, 92, 1

**RGB**: 253, 185, 19, 99

**HEX**: #FDB913

**PMS**: 7209C 

## ![#ed1a3b](https://placehold.co/15x15/ed1a3b/ed1a3b.png) Röd
**CMYK**: 0, 100, 80, 0

**RGB**: 237, 26, 59

**HEX**: #ed1a3b

**PMS**: 185C 


## ![#ec00bc](https://placehold.co/15x15/ec00bc/ec00bc.png) Magenta
**CMYK**: 0, 100, 41, 

**RGB**: 236, 0, 140, 93

**HEX**: #EC008C

**PMS**: 219C 
