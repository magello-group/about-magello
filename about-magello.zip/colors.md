## ![#009FE3](https://placehold.co/32x32/009FE3/009FE3.png) Blå

**CMYK**: 100, 30, 0, 11

**PMS**: 2925C

**RGB**: 0, 158, 227

**HEX**: #009EE3

## ![#00A65D](https://placehold.co/32x32/00A65D/00A65D.png) Grön

**CMYK**: 100, 0, 44, 35

**PMS**: 7739C

**RGB**: 0, 166, 93

**HEX**: #00A65D

## ![#ffdd00](https://placehold.co/32x32/ffdd00/ffdd00.png) Gul

**CMYK**: 0, 13, 100, 0

**PMS**: 107C
'
**RGB**: 255, 221, 0

**HEX**: #FFDD00

## ![#FDB913](https://placehold.co/32x32/FDB913/FDB913.png) Senapsgul

**CMYK**: 0, 27, 92, 1

**PMS**: 7209C

**RGB**: 253, 185, 19

**HEX**: #FDB913

## ![#ED1A3B](https://placehold.co/32x32/ED1A3B/ED1A3B.png) Röd

**CMYK**: 0, 100, 80, 0

**PMS**: 185C

**RGB**: 237, 26, 59

**HEX**: #ED1A3B

## ![#EC008C](https://placehold.co/32x32/EC008C/EC008C.png) Magenta

**CMYK**: 0, 100, 0, 0

**PMS**: 219C

**RGB**: 236, 0, 140

**HEX**: #EC008C

## ![#F7F3F3](https://placehold.co/32x32/F7F3F3/F7F3F3.png) Primärgrå

**HEX**: #F7F3F3

## ![#F8F8F8](https://placehold.co/32x32/F8F8F8/F8F8F8.png) Ljusgrå

**HEX**: #F8F8F8


